@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ====================================================
echo   Building ModiriatSefareshPro Android APK (v3.2)
echo ====================================================
echo.
where gradle >nul 2>&1
if errorlevel 1 (
    echo [INFO] Gradle is not installed in PATH.
    echo You have two easy ways to get your APK:
    echo   1. Open this folder in Android Studio -> Build -> Build APK(s)
    echo   2. Upload this folder to a GitHub repo -> Actions tab -> Download APK automatically!
    pause
    exit /b 1
)
gradle assembleDebug
if exist "app\build\outputs\apk\debug\app-debug.apk" (
    copy /Y "app\build\outputs\apk\debug\app-debug.apk" "ModiriatSefareshPro-v3.2.apk" >nul
    echo.
    echo SUCCESS! APK created: ModiriatSefareshPro-v3.2.apk
) else (
    echo [ERROR] Build failed. Check the messages above.
)
pause
